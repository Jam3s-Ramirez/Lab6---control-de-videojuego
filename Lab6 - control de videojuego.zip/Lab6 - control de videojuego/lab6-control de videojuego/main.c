/**************************
Universidad del Valle de Guatemala
Electr�nica digital 2
Proyecto: lab6-control de videojuego.c
Hardware: ATMEGA328p
Created: 20/09/2024 10:48:05
Author : James Ram�rez
***************************/

#define F_CPU 16000000
#include <avr/io.h>
#include <avr/interrupt.h>

// Configuraci�n UART
#define UART_BAUD_RATE 9600
#define UART_UBRR (F_CPU / 16 / UART_BAUD_RATE - 1)

void uart_init(void) {
	// Configuraci�n de los pines de UART
	DDRD |= (1 << DDD1); // Pin TX como salida
	DDRD &= ~(1 << DDD0); // Pin RX como entrada
	
	UBRR0H = (UART_UBRR >> 8);
	UBRR0L = UART_UBRR;
	UCSR0B = (1 << TXEN0) | (1 << RXEN0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void uart_send_char(uint8_t data) {
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = data;
}

void uart_send_string(char* str) {
	while (*str != '\0') {
		uart_send_char(*str);
		str++;
	}
}

int main() {
	// Configuraci�n de los pines PD2-PD7 como entradas para los push
	DDRD &= ~(1 << DDD2) & ~(1 << DDD3) & ~(1 << DDD4) & ~(1 << DDD5) & ~(1 << DDD6) & ~(1 << DDD7);
	PORTD |= (1 << PORTD2)|(1 << PORTD3)|(1 << PORTD4)|(1 << PORTD5)|(1 << PORTD6)|(1 << PORTD7); //Habilita pull-up
	PCICR |= (1 << PCIE2); // Habilita las interrupciones en el puerto D
	PCMSK2 |= (1 << PCINT2) | (1 << PCINT3) | (1 << PCINT4) | (1 << PCINT5) | (1 << PCINT6) | (1 << PCINT7);

	while (1) {

	}

	return 0;
}

ISR(PCINT2_vect) {
	if (bit_is_clear(PIND, 2)) { // Verifica si el bot�n 1 (PD2) est� presionado
		uart_send_string("1");
	}
	
	if (bit_is_clear(PIND, 3)) { // Verifica si el bot�n 2 (PD3) est� presionado
		uart_send_string("2");
	}
	
	if (bit_is_clear(PIND, 4)) { // Verifica si el bot�n 3 (PD4) est� presionado
		uart_send_string("3");
	}
	
	if (bit_is_clear(PIND, 5)) { // Verifica si el bot�n 4 (PD5) est� presionado
		uart_send_string("4");
	}
	
	if (bit_is_clear(PIND, 6)) { // Verifica si el bot�n 5 (PD6) est� presionado
		uart_send_string("5");
	}
	
	if (bit_is_clear(PIND, 7)) { // Verifica si el bot�n 6 (PD7) est� presionado
		uart_send_string("6");
	}
}